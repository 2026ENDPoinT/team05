/* GradePath 화면 동작
   화면은 계산을 하지 않고, 서버(app.py)에 요청해서 받은 결과를 보여 주기만 합니다. */

const $ = (id) => document.getElementById(id);
let S = null;          // 서버에서 받아 온 전체 상태
let SUM = null;        // 요약(누적 평균 학점, 학기별 평균 학점 등)
let CANDS = [];        // 재수강 후보 목록
let editC = null;      // 수정 중인 지난 학기 과목 id
let editU = null;      // 수정 중인 이번 학기 과목 id
let lastRetake = null; // 마지막으로 분석한 재수강 과목 {source, id}
let currentTab = "grades";

const TYPE_TEXT = { major: "전공", lib: "교양" };
// P/F 과목 성적 표시: 내부 값 P / NP를 학교 용어(합격 / F)로 보여 줌
const gradeText = (g) => (g === "NP" ? "F(P/F)" : g);
const typeLabel = (c) => TYPE_TEXT[c.type] + (c.required ? " · 필수" : "");

/* 용어 설명 (물음표 버튼에 마우스를 올리거나 누르면 보입니다) */
const GLOSSARY = {
  z: ["Z점수", "내 점수가 반 평균보다 표준편차 몇 개만큼 높은지(+) 낮은지(−) 나타낸 값입니다. z = (내 점수 − 평균) ÷ 표준편차. 0이면 평균, +1이면 평균보다 표준편차 1개만큼 위입니다."],
  std: ["표준편차", "점수가 평균 주변에 얼마나 흩어져 있는지를 나타내는 값입니다. 클수록 학생들 점수 차이가 큽니다."],
  top: ["예상 상위 비율", "z점수를 바탕으로, 점수가 종 모양(정규분포)으로 퍼져 있다고 가정했을 때 내가 반에서 상위 몇 %쯤인지 추정한 값입니다. 작을수록 상위입니다. 실제 등수와 다를 수 있습니다."],
  range: ["점수가 바뀌면(참고)", "현재 점수가 기말까지 표준편차의 일정 배수만큼 오르거나 내릴 수 있다고 가정했을 때의 최저~최고 학점입니다. 확정 성적이 아니며, 변동 폭은 '계산 기준'의 임의 설정값입니다."],
  maxg: ["최대 학점", "현재 점수 위치에서 교수님이 윗 등급을 최대한 많이 줄 때 받을 수 있는 학점입니다. 학칙상 A0 이상은 30% 이하, B0 이상은 70% 이하이고, 그 안에서 A+/A0, B+/B0 비율은 교수님이 정합니다. 상위 30% 이내면 A+, 30~70%면 B+, 그 아래는 C+입니다."],
  ming: ["최소 학점", "현재 점수 위치에서 구간 상한까지 등급이 채워진다고 가정할 때 최소한 받을 수 있는 학점입니다. 상위 30% 이내면 A0, 30~70%면 B0입니다. 교수님이 A를 적게 주면 이보다 낮아질 수 있습니다."],
  need: ["필요한 평균 평점", "목표 누적 평균 학점을 달성하려면 이번 학기 과목들의 학점 가중 평균 평점이 얼마여야 하는지입니다. 4.5를 넘으면 이번 학기만으로는 달성할 수 없습니다."],
  prob: ["목표 달성 가능성", "앞으로 점수가 현재 위치에서 무작위로 흔들린다고 가정하고 3000번 모의 계산했을 때, 목표 평균 학점에 도달한 비율로 정한 대략적인 가능성입니다. 실제로 검증된 확률이 아니라 가정에 따른 참고 지표입니다."],
  gparange: ["누적 평균 학점 예상 범위", "모의 계산 3000번 결과 중 가운데 80%(작은 쪽 10%와 큰 쪽 10%를 뺀 구간)가 들어가는 누적 평균 학점 범위입니다."],
  semgpa: ["이번 학기 평균 학점", "이번 학기 과목만으로 계산한 평점평균입니다."],
  cumgpa: ["누적 평균 학점", "지금까지 들은 모든 학기 과목을 합쳐서 계산한 평점평균입니다."],
};

/* ---------- 도우미 ---------- */

async function api(method, url, body) {
  const res = await fetch(url, {
    method,
    headers: body ? { "Content-Type": "application/json" } : {},
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "오류가 발생했습니다.");
  return data;
}

// 요소 만들기: el("td", {class:"num"}, "텍스트")  (textContent만 써서 입력값이 코드로 실행되지 않게 함)
function el(tag, props, ...kids) {
  const e = document.createElement(tag);
  for (const k in props || {}) {
    if (k === "class") e.className = props[k];
    else if (k.startsWith("on")) e[k] = props[k];
    else e.setAttribute(k, props[k]);
  }
  for (const kid of kids.flat()) {
    if (kid === null || kid === undefined) continue;
    e.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return e;
}

// 용어 + 물음표 도움말
function term(key, label) {
  const [name, text] = GLOSSARY[key];
  return el("span", { class: "term" }, label || name,
    el("button", { type: "button", class: "help", "data-tip": `${name}: ${text}`, "aria-label": name + " 설명" }, "?"));
}

const f2 = (v) => (v === null || v === undefined ? "-" : v.toFixed(2));
const signed = (v) => (v > 0.0049 ? "+" : "") + v.toFixed(2);
const diff = (a, b) => (a === null || b === null ? "-" : signed(b - a));
const fillSelect = (sel, options, selected) => {
  sel.innerHTML = "";
  for (const [value, text] of options) {
    const o = el("option", { value }, text);
    if (value === selected) o.selected = true;
    sel.append(o);
  }
};

function table(headers, rows, numFrom = 1) {
  const thead = el("thead", {}, el("tr", {}, headers.map((h, i) => el("th", { class: i >= numFrom ? "num" : "" }, h))));
  const tbody = el("tbody", {}, rows);
  return el("div", { class: "scroll" }, el("table", {}, thead, tbody));
}
const tr = (cells, numFrom = 1) =>
  el("tr", {}, cells.map((c, i) => el("td", { class: i >= numFrom ? "num" : "" }, c)));

function cards(items, two) {
  return el("div", { class: "cards" + (two ? " two" : "") },
    items.map(([label, value, note]) =>
      el("div", { class: "card" }, el("div", { class: "label" }, label),
        el("div", { class: "value" }, value), note ? el("div", { class: "note" }, note) : null)));
}

function say(id, text) { $(id).textContent = text || ""; }

/* ---------- 도움말 말풍선 ---------- */

const tip = $("tip");
function showTip(btn) {
  tip.textContent = btn.dataset.tip;
  tip.hidden = false;
  const r = btn.getBoundingClientRect();
  const w = tip.offsetWidth;
  let left = r.left + window.scrollX + r.width / 2 - w / 2;
  left = Math.max(8, Math.min(left, window.scrollX + document.documentElement.clientWidth - w - 8));
  tip.style.left = left + "px";
  tip.style.top = r.bottom + window.scrollY + 8 + "px";
}
document.addEventListener("mouseover", (e) => { if (e.target.classList.contains("help")) showTip(e.target); });
document.addEventListener("mouseout", (e) => { if (e.target.classList.contains("help")) tip.hidden = true; });
document.addEventListener("focusin", (e) => { if (e.target.classList.contains("help")) showTip(e.target); });
document.addEventListener("focusout", () => { tip.hidden = true; });
document.addEventListener("click", (e) => {
  if (e.target.classList.contains("help")) { e.preventDefault(); showTip(e.target); }
  else tip.hidden = true;
});

/* ---------- 탭 / 모드 ---------- */

function showTab(tab) {
  currentTab = tab;
  for (const b of $("nav").children) b.classList.toggle("active", b.dataset.tab === tab);
  for (const t of document.querySelectorAll(".tab")) t.hidden = t.id !== "tab-" + tab;
  const nb = $("nav").querySelector(`[data-tab="${tab}"]`);
  $("pageTitle").textContent = nb ? nb.firstChild.textContent.trim() : "";
  if (tab === "withdraw") renderWithdrawSelect();
  if (tab === "guide") renderGuide();
  renderSetupNotice();
  window.scrollTo(0, 0);
}
$("nav").addEventListener("click", (e) => {
  const b = e.target.closest("button");
  if (b && b.dataset.tab) showTab(b.dataset.tab);
});

const MODE_NOTES = {
  predict: {
    mid: "중간고사 이후 모드: 기말까지 점수가 많이 바뀔 수 있다고 보고 예상 범위를 넓게 계산합니다.",
    final: "기말고사 이후 모드: 점수가 거의 확정됐다고 보고 예상 범위를 좁게 계산합니다. 확정된 성적은 '내 성적' 탭에 입력해 두세요.",
  },
  withdraw: {
    mid: "수강 철회는 보통 중간고사 이후에 판단합니다. 철회 가능 기간은 학사일정에서 확인하세요.",
    final: "기말고사 이후에는 철회 신청 기간이 이미 지났을 수 있습니다. 참고용 비교로만 사용하세요.",
  },
  retake: {
    mid: "재수강은 기말고사 이후 성적이 확정된 뒤 판단하는 기능입니다. 지금은 미리 확인용으로 볼 수 있고, 이번 학기 과목은 현재 점수 기준 예상 성적으로 계산합니다.",
    final: "기말고사 이후 모드: 최종 성적을 기준으로 재수강 여부를 판단합니다.",
  },
};

function renderMode() {
  const m = S.settings.mode;
  for (const b of document.querySelectorAll("[data-mode]")) {
    if (b.closest("#intro")) continue;
    b.classList.toggle("on", b.dataset.mode === m);
  }
  for (const t of document.querySelectorAll(".tabtag")) t.classList.toggle("match", t.dataset.when === m);
  $("noteMid").textContent = MODE_NOTES.predict[m];
  $("noteWithdraw").textContent = MODE_NOTES.withdraw[m];
  $("noteRetake").textContent = MODE_NOTES.retake[m];
}

async function setMode(m) {
  await api("PUT", "/api/mode", { mode: m });
  await loadAll();
  $("predictResult").innerHTML = "";
  $("withdrawResult").innerHTML = "";
  $("retakeResult").innerHTML = "";
}
$("modeSwitch").addEventListener("click", (e) => {
  const m = e.target.dataset.mode;
  if (m) setMode(m);
});

/* ---------- 사용방법 (첫 접속 안내) ---------- */

let introMode = "mid";
function openIntro() {
  introMode = S.settings.mode;
  paintIntroMode();
  $("intro").hidden = false;
}
function paintIntroMode() {
  for (const b of $("introMode").children) b.classList.toggle("on", b.dataset.mode === introMode);
}
$("introMode").addEventListener("click", (e) => {
  const b = e.target.closest("button");
  if (b) { introMode = b.dataset.mode; paintIntroMode(); }
});
async function closeIntro(never) {
  $("intro").hidden = true;
  const first = !S.settings_done;
  if (introMode !== S.settings.mode) await api("PUT", "/api/mode", { mode: introMode });
  if (never) await api("PUT", "/api/onboarded", { onboarded: true });
  await loadAll();
  if (first) showTab("settings");          // 처음이면 설정부터 확인하게 함
}
$("introStart").addEventListener("click", () => closeIntro(false));
$("introNever").addEventListener("click", () => closeIntro(true));
$("helpBtn").addEventListener("click", openIntro);
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("intro").hidden) closeIntro(false); });

/* ---------- 설정 안내 (저장 전에는 기본값으로 계산 중임을 알림) ---------- */

function renderSetupNotice() {
  const need = !S.settings_done;
  $("setupBanner").hidden = !(need && currentTab !== "settings" && currentTab !== "grades");
  $("setupFirst").hidden = !need;
}
$("goSettings").addEventListener("click", () => showTab("settings"));

/* ---------- 불러오기 ---------- */

async function loadAll() {
  S = await api("GET", "/api/state");
  const sum = await api("GET", "/api/summary");
  SUM = sum;
  CANDS = (await api("GET", "/api/retake/candidates")).candidates;
  renderMode();
  renderSetupNotice();
  renderSummary(sum);
  renderCompleted();
  renderCurrent();
  renderSettings();
  renderWithdrawSelect();
  renderSimSelect();
  renderRetakeList();
}

/* ---------- 1. 내 성적 ---------- */

function renderSummary(sum) {
  $("summary").innerHTML = "";
  const stat = (label, value, unit) =>
    el("div", { class: "stat" }, el("div", { class: "label" }, label),
      el("div", { class: "value" }, value, unit ? el("small", {}, unit) : null));
  $("summary").append(
    stat("누적 평균 학점", f2(sum.gpa), "/ 4.5"),
    stat("등록 학점", sum.registered, "학점"),
    stat("취득 학점", sum.earned, "학점"),
    stat("전공", sum.major, "학점"),
    stat("교양", sum.lib, "학점"));
  const b = sum.burden;
  $("gradLine").innerHTML = "";
  $("gradLine").append(
    "졸업까지 ", el("b", {}, b.remaining + "학점"), " 남음 (총 ", sum.required, "학점 기준) · 전공 ",
    el("b", {}, sum.major_remaining + "학점"), " 남음 (", sum.major_required, "학점 기준)");
  const x = sum.extra_credit;
  if (x) {
    $("gradLine").append(el("div", { class: "dim" }, x.eligible
      ? `직전 학기(${x.semester}) 평균 학점 ${f2(x.gpa)}, 취득 ${x.earned}학점 → 다음 학기 ${x.extra}학점 추가 신청 가능 (최대 ${x.next_max}학점, 그 학기에만 적용)`
      : `직전 학기(${x.semester}) 평균 학점 ${f2(x.gpa)}, 취득 ${x.earned}학점 → 추가 신청 조건(평균 학점 ${x.min_gpa} 이상, ${x.min_earned}학점 이상 취득) 미충족. 입력한 마지막 학기를 직전 학기로 봅니다.`));
  }
  const tr_ = sum.semesters.filter((x) => x.gpa !== null && x.gpa !== undefined).map((x) => ({ semester: x.name, gpa: x.gpa }));
  $("trendSection").hidden = tr_.length === 0;
  $("trendChart").innerHTML = "";
  if (tr_.length) $("trendChart").append(trendChart(tr_));
  if (b.seasonal_plan > 0) {
    $("gradLine").append(el("div", { class: "dim" },
      `계절학기 계획 ${b.seasonal_plan}학점을 반영하면 정규 학기에 ${b.need_regular}학점이 남습니다.`));
  }
}

function resetCompletedForm() {
  editC = null;
  $("cSubmit").textContent = "추가";
  $("cCancel").hidden = true;
  $("cName").value = "";
  $("cCredit").value = 3;
  $("cMajor").checked = false;
  $("cRequired").checked = false;
  $("cGrade").value = "A+";
}

function renderCompleted() {
  fillSelect($("cGrade"), [...S.grades.map((g) => [g, g === "F" ? "F (일반 과목, 평점 0)" : g]), ["P", "합격 (P/F 과목)"], ["NP", "불합격 (P/F 과목)"]], $("cGrade").value || "A+");
  const box = $("completedList");
  box.innerHTML = "";
  if (S.completed.length === 0) {
    box.append(el("div", { class: "empty" }, "아직 입력한 성적이 없습니다."));
    return;
  }
  const retakable = new Set(CANDS.filter((x) => x.source === "completed").map((x) => x.id));
  const groups = {};
  for (const c of S.completed) (groups[c.semester] = groups[c.semester] || []).push(c);
  for (const name in groups) {
    const list = groups[name];
    const info = SUM.semesters.find((x) => x.name === name);
    box.append(el("div", { class: "sem-title" }, name,
      el("span", {}, `평균 학점 ${f2(info.gpa)} · 등록 ${info.credits}학점 · 취득 ${info.earned}학점`)));
    box.append(table(["과목명", "구분", "학점", "성적", ""],
      list.map((c) => el("tr", {},
        el("td", {}, c.name),
        el("td", { class: "num" }, el("span", { class: "tag" }, typeLabel(c))),
        el("td", { class: "num" }, c.credit),
        el("td", { class: "num" }, gradeText(c.grade)),
        el("td", { class: "num acts" },
          retakable.has(c.id) ? el("button", { class: "btn-link", onclick: () => goRetake("completed", c.id) }, "재수강 분석") : null,
          el("button", { class: "btn-ghost", onclick: () => startEditCompleted(c) }, "수정"),
          el("button", { class: "btn-ghost", onclick: async () => {
            await api("DELETE", "/api/completed/" + c.id);
            if (editC === c.id) resetCompletedForm();
            loadAll();
          } }, "삭제"))))));
  }
}

function startEditCompleted(c) {
  editC = c.id;
  $("cSemester").value = c.semester;
  $("cName").value = c.name;
  $("cCredit").value = c.credit;
  $("cMajor").checked = c.type === "major";
  $("cRequired").checked = c.required;
  $("cGrade").value = c.grade;
  $("cSubmit").textContent = "수정 저장";
  $("cCancel").hidden = false;
  say("cMsg", `'${c.name}' 과목을 수정하는 중입니다.`);
  $("completedForm").scrollIntoView({ behavior: "smooth", block: "center" });
}
$("cCancel").addEventListener("click", () => { resetCompletedForm(); say("cMsg", ""); });

$("completedForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  say("cMsg", "");
  const body = {
    semester: $("cSemester").value, name: $("cName").value, credit: $("cCredit").value,
    type: $("cMajor").checked ? "major" : "lib", required: $("cRequired").checked, grade: $("cGrade").value,
  };
  try {
    if (editC) await api("PUT", "/api/completed/" + editC, body);
    else await api("POST", "/api/completed", body);
    resetCompletedForm();
    await loadAll();
  } catch (err) { say("cMsg", err.message); }
});

/* 스프레드시트에서 불러오기: 파일 선택 -> 미리 보기 -> 확인 후 추가 */
let importRows = [];

function clearImport() {
  $("importFile").value = "";
  $("importPreview").innerHTML = "";
  importRows = [];
}

$("importFile").addEventListener("change", async () => {
  const file = $("importFile").files[0];
  say("importMsg", "");
  $("importPreview").innerHTML = "";
  importRows = [];
  if (!file) return;
  const form = new FormData();
  form.append("file", file);
  try {
    const res = await fetch("/api/import/preview", { method: "POST", body: form });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "파일을 읽지 못했습니다.");
    renderImportPreview(data);
  } catch (err) { say("importMsg", err.message); }
});

function renderImportPreview(data) {
  const box = $("importPreview");
  const fresh = data.rows.filter((r) => !r.duplicate);
  const dup = data.rows.length - fresh.length;
  importRows = fresh;
  box.append(el("div", { class: "sub-title" },
    `읽은 과목 ${data.rows.length}개 · 새로 추가 ${fresh.length}개` + (dup ? ` · 이미 있어 제외 ${dup}개` : "") +
    (data.errors.length ? ` · 오류 ${data.errors.length}줄` : "")));
  if (data.rows.length) {
    box.append(table(["줄", "학기", "과목명", "구분", "학점", "성적", "상태"],
      data.rows.map((r) => el("tr", { class: r.duplicate ? "dup" : "" },
        el("td", { class: "num" }, r.line),
        el("td", {}, r.semester),
        el("td", {}, r.name),
        el("td", { class: "num" }, el("span", { class: "tag" }, typeLabel(r))),
        el("td", { class: "num" }, r.credit),
        el("td", { class: "num" }, gradeText(r.grade)),
        el("td", { class: "num" }, r.duplicate ? "중복(제외)" : "추가")))));
  }
  if (data.errors.length) {
    box.append(el("div", { class: "callout" }, "아래 줄은 오류가 있어 불러오지 않습니다. 파일을 고친 뒤 다시 올려 주세요.",
      el("ul", {}, data.errors.map((e) => el("li", {}, `${e.line}번째 줄: ${e.message}`)))));
  }
  const actions = el("div", { class: "row import-actions" });
  if (fresh.length) {
    actions.append(el("button", { class: "btn", type: "button", onclick: confirmImport }, `${fresh.length}개 과목 추가`));
  }
  actions.append(el("button", { class: "btn-ghost", type: "button", onclick: () => { clearImport(); say("importMsg", ""); } }, "취소"));
  box.append(actions);
}

async function confirmImport() {
  try {
    const r = await api("POST", "/api/completed/bulk", { rows: importRows });
    clearImport();
    say("importMsg", `${r.added}개 과목을 추가했습니다.` + (r.skipped ? ` (중복 ${r.skipped}개 제외)` : ""));
    await loadAll();
  } catch (err) { say("importMsg", err.message); }
}

/* ---------- 2. 성적 예측 ---------- */

function resetCurrentForm() {
  editU = null;
  $("uSubmit").textContent = "추가";
  $("uCancel").hidden = true;
  for (const id of ["uName", "uScore", "uMax", "uMean", "uStd", "uExamRatio", "uFinRatio", "uFinMax"]) $(id).value = "";
  $("uCredit").value = 3;
  $("uMajor").checked = false;
  $("uRequired").checked = false;
  $("uUseExtra").checked = false;
  $("uItems").innerHTML = "";
  syncExtra();
  applyMax();
}

/* 만점 칸에 적은 값(비우면 100)을 점수·평균·표준편차 칸의 입력 한도로 반영: "값은 35 이하여야 합니다" */
const maxOf = (v) => (parseFloat(v) > 0 ? parseFloat(v) : 100);
function applyMax() {
  const m = maxOf($("uMax").value);
  $("uScore").max = m;
  $("uMean").max = m;
  $("uStd").max = m / 2;
  for (const r of $("uItems").children) r.querySelector(".it-score").max = maxOf(r.querySelector(".it-max").value);
}
$("uMax").addEventListener("input", applyMax);

/* 반영 비율 입력: 체크하면 중간·기말 비율과 항목(퀴즈·과제·출석 등) 입력줄이 나타남 (기본은 중간고사 점수만) */
function syncExtra() {
  $("uExtra").hidden = !$("uUseExtra").checked;
  if ($("uUseExtra").checked && $("uItems").children.length === 0 && !$("uExamRatio").value) addItemRow();
  updateRatioSum();
}
function addItemRow(it) {
  const row = el("div", { class: "item-row" },
    el("input", { type: "text", lang: "ko", class: "it-name", placeholder: "항목 (예: 퀴즈)", maxlength: 20, value: it ? it.name : "" }),
    el("input", { type: "number", class: "it-score", step: "0.01", min: 0, max: it && it.max ? it.max : 100, placeholder: "점수", value: it ? it.score : "" }),
    el("input", { type: "number", class: "it-max", step: "0.01", min: 0, placeholder: "만점(100)", title: "항목 만점 (비우면 100)", value: it && it.max ? it.max : "" }),
    el("input", { type: "number", class: "it-ratio", step: "0.01", min: 0.01, max: 100, placeholder: "비율(%)", value: it ? it.ratio : "" }),
    el("button", { type: "button", class: "btn-ghost", onclick: () => { row.remove(); updateRatioSum(); } }, "삭제"));
  row.addEventListener("input", () => { applyMax(); updateRatioSum(); });
  $("uItems").append(row);
}
function readItems() {
  return [...$("uItems").children].map((r) => ({
    name: r.querySelector(".it-name").value, score: r.querySelector(".it-score").value,
    max: r.querySelector(".it-max").value, ratio: r.querySelector(".it-ratio").value,
  }));
}
function updateRatioSum() {
  if (!$("uUseExtra").checked) { say("uRatioSum", ""); return; }
  const sum = [$("uExamRatio").value, $("uFinRatio").value, ...readItems().map((i) => i.ratio)]
    .reduce((a, v) => a + (parseFloat(v) || 0), 0);
  say("uRatioSum", `비율 합계 ${Math.round(sum * 100) / 100}%` + (sum > 100 ? " (100%를 넘을 수 없습니다)" : ""));
}
$("uUseExtra").addEventListener("change", syncExtra);
$("uAddItem").addEventListener("click", () => addItemRow());
$("uExamRatio").addEventListener("input", updateRatioSum);
$("uFinRatio").addEventListener("input", updateRatioSum);

function evalText(c) {
  if (c.exam_ratio === undefined) return "중간고사만";
  const parts = [`중간 ${c.exam_ratio}%`];
  if (c.fin_ratio !== undefined) parts.push(`기말 ${c.fin_ratio}% (점수 미정${c.fin_max ? ", 만점 " + c.fin_max : ""})`);
  for (const it of c.items || []) parts.push(`${it.name} ${it.score}${it.max ? "/" + it.max : ""}점 ${it.ratio}%`);
  return parts.join(" · ");
}

function renderCurrent() {
  fillSelect($("uGrading"), Object.entries(S.grading_modes), $("uGrading").value || "relative");
  const box = $("currentList");
  box.innerHTML = "";
  if (S.current.length === 0) {
    box.append(el("div", { class: "empty" }, "이번 학기 과목을 추가해 주세요."));
    return;
  }
  box.append(table(["과목명", "구분", "학점", "중간 점수", "평균", "표준편차", "반영 항목", "평가 방식", ""],
    S.current.map((c) => el("tr", {},
      el("td", {}, c.name),
      el("td", { class: "num" }, el("span", { class: "tag" }, typeLabel(c))),
      el("td", { class: "num" }, c.credit),
      el("td", { class: "num" }, c.max_score ? `${c.score}/${c.max_score}` : c.score),
      el("td", { class: "num" }, c.mean),
      el("td", { class: "num" }, c.std),
      el("td", {}, evalText(c)),
      el("td", { class: "num" }, S.grading_modes[c.grading]),
      el("td", { class: "num acts" },
        el("button", { class: "btn-ghost", onclick: () => startEditCurrent(c) }, "수정"),
        el("button", { class: "btn-ghost", onclick: async () => {
          await api("DELETE", "/api/current/" + c.id);
          if (editU === c.id) resetCurrentForm();
          loadAll();
        } }, "삭제"))))));
}

function startEditCurrent(c) {
  editU = c.id;
  $("uName").value = c.name;
  $("uCredit").value = c.credit;
  $("uMajor").checked = c.type === "major";
  $("uRequired").checked = c.required;
  $("uScore").value = c.score;
  $("uMax").value = c.max_score ?? "";
  $("uMean").value = c.mean;
  $("uStd").value = c.std;
  $("uGrading").value = c.grading;
  $("uExamRatio").value = c.exam_ratio ?? "";
  $("uFinRatio").value = c.fin_ratio ?? "";
  $("uFinMax").value = c.fin_max ?? "";
  $("uItems").innerHTML = "";
  for (const it of c.items || []) addItemRow(it);
  applyMax();
  $("uUseExtra").checked = c.exam_ratio !== undefined;
  syncExtra();
  $("uSubmit").textContent = "수정 저장";
  $("uCancel").hidden = false;
  say("uMsg", `'${c.name}' 과목을 수정하는 중입니다.`);
  $("currentForm").scrollIntoView({ behavior: "smooth", block: "center" });
}
$("uCancel").addEventListener("click", () => { resetCurrentForm(); say("uMsg", ""); });

$("currentForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  say("uMsg", "");
  const body = {
    name: $("uName").value, credit: $("uCredit").value, type: $("uMajor").checked ? "major" : "lib", required: $("uRequired").checked,
    score: $("uScore").value, max_score: $("uMax").value, mean: $("uMean").value, std: $("uStd").value, grading: $("uGrading").value,
  };
  if ($("uUseExtra").checked) {
    body.exam_ratio = $("uExamRatio").value;
    if ($("uFinRatio").value) { body.fin_ratio = $("uFinRatio").value; body.fin_max = $("uFinMax").value; }
    body.items = readItems().filter((i) => i.name || i.score || i.ratio);
  }
  try {
    if (editU) await api("PUT", "/api/current/" + editU, body);
    else await api("POST", "/api/current", body);
    resetCurrentForm();
    await loadAll();
  } catch (err) { say("uMsg", err.message); }
});

/* 계산 기준 상자 (학교 규정 vs 프로그램 가정) */
async function renderRules(target) {
  const r = await api("GET", "/api/rules");
  target.innerHTML = "";
  target.append(
    el("div", { class: "rules" },
      el("div", {}, el("div", { class: "rules-title" }, "학교 규정 · 확인된 기준"),
        el("ul", {}, r.school.map((t) => el("li", {}, t)))),
      el("div", {}, el("div", { class: "rules-title" }, "프로그램의 가정 (실제와 다를 수 있음)"),
        el("ul", {}, r.assumptions.map((t) => el("li", {}, t))))));
}
$("rulesBtn").addEventListener("click", async () => {
  const box = $("rulesBox");
  if (box.hidden) { await renderRules(box); box.hidden = false; $("rulesBtn").textContent = "계산 기준 닫기"; }
  else { box.hidden = true; $("rulesBtn").textContent = "계산 기준 보기"; }
});

const PLAN_GRADES = ["A+", "A0", "B+", "B0", "C+", "C0", "D+", "D0"];
let planPick = "all";      // 기말 계획 그래프에서 고른 과목 (all = 전체)
const planTarget = {};      // 과목별로 고른 목표 학점 (화면에서만 기억)

/* 기말 점수 구간: 결론 문장 + 한 줄 띠 + 구간 목록 */
function finalBand(fn, tg, need) {
  const max = fn.final_max;
  const pct = (v) => Math.max(0, Math.min(100, (v / max) * 100));
  const segs = [];                                     // 점수가 낮은 쪽부터
  const none = [];
  fn.grades.forEach((g, i) => {
    const up = i > 0 ? fn.grades[i - 1] : null;
    if (g.min_score === null) { segs.push({ grade: g.grade, impossible: true }); return; }
    const hi = up && up.min_score !== null ? up.min_score : max;
    if (hi <= g.min_score) { none.push(g.grade); return; }
    segs.push({ grade: g.grade, lo: g.min_score, hi });
  });
  const ok = segs.filter((x) => !x.impossible).reverse();
  const head = need.min_score === null ? [`${tg}는 기말 만점(${max}점)으로도 어려워요.`]
    : need.min_score === 0 ? [`${tg}는 기말 0점이어도 가능합니다.`, el("small", {}, "(평균 가정 기준)")]
    : [`${tg}를 받으려면`, el("br"), `기말 `, el("u", {}, `${need.min_score}점 이상`), `이 필요합니다.`];
  const box = el("div", { class: "fp" }, el("div", { class: "fp-head" }, head));
  const mine = ok.find((x) => x.grade === tg);
  if (ok.length) {
    const bar = el("div", { class: "fp-bar" }), below = el("div", { class: "fp-small" });
    ok.forEach((x) => {
      const w = pct(x.hi) - pct(x.lo);
      const on = x.grade === tg;
      const cell = el("div", { class: "fp-seg" + (on ? " on" : ""), style: `width:${w}%` }, w >= 3.5 ? x.grade : "");
      if (on && w >= 14) cell.append(el("span", {}, "목표"));
      bar.append(cell);
      if (w < 3.5) below.append(el("span", { style: pct(x.lo) > 50 ? `right:${100 - pct(x.hi)}%` : `left:${pct(x.lo)}%` }, `${x.grade} ${x.lo}~${x.hi}`));
    });
    const wrap = el("div", { class: "fp-wrap" });
    if (mine) {
      const ex = Math.min(max, Math.round((mine.lo + mine.hi) / 2));
      const at = Math.min(92, Math.max(8, pct(ex)));
      wrap.append(el("div", { class: "fp-pin", style: `left:${at}%` }, el("div", {}, `예: ${ex}점이면 ${tg}`), el("div", {}, "▼")));
    }
    wrap.append(bar);
    const ticks = el("div", { class: "fp-ticks" });
    let last = -99;
    const xs = [...ok.map((x) => x.lo), max];
    xs.forEach((v) => {
      const p = pct(v);
      if (p - last < 4 && !(mine && v === mine.lo)) return;
      last = p;
      ticks.append(el("span", { class: mine && v === mine.lo ? "hit" : "", style: `left:${p}%` }, v === max ? `${max}점` : String(v)));
    });
    wrap.append(ticks, below);
    box.append(wrap);
  }
  const list = el("div", { class: "fp-list" });
  segs.forEach((x) => {
    list.append(el("div", { class: "fp-li" + (x.grade === tg ? " on" : "") }, el("span", {}, x.grade),
      el("span", {}, x.impossible ? `만점(${max}점)으로도 어려움` : x.hi >= max ? `${x.lo}점 이상` : `${x.lo}점 ~ ${x.hi}점 미만`)));
  });
  box.append(list);
  if (none.length) box.append(el("div", { class: "fp-foot" }, `${none.join("·")}는 기말 0점이어도 더 높은 학점이 나와서, 해당하는 구간이 없습니다.`));
  return box;
}

function renderFinalPlan(c, fn, makePick) {
  const box = el("div", { class: "plan" });
  const target = planTarget[c.id] || "A0";
  const draw = () => {
    box.innerHTML = "";
    const cur = fn.current;
    const tg = planTarget[c.id] || target;
    const sel = el("select", { class: "target-sel", onchange: (e) => { planTarget[c.id] = e.target.value; draw(); } },
      PLAN_GRADES.map((g) => el("option", { value: g }, g)));
    sel.value = tg;
    const need = fn.grades.find((g) => g.grade === tg);
    box.append(el("div", { class: "sub-title plan-title" }, makePick(), " 기말고사를 몇 점 맞으면?"));
    box.append(el("div", { class: "row target-row" }, "목표 학점", sel));
    box.append(finalBand(fn, tg, need));
    box.append(el("div", { class: "dim plan-note" }, "중간고사 정보를 바탕으로 만들어진 결과입니다. 실제 기말시험에 따라 달라질 수 있습니다."));
    box.append(cards([
      ["지금까지 환산 점수", cur.converted === null ? "-" : cur.converted.toFixed(1), `반영된 ${cur.known_ratio}% 중 100점 만점 기준`],
      ["지금까지 얻은 점수", cur.earned.toFixed(1), `총점 ${cur.total_ratio}점 만점 중`],
      ["기말까지 모두 맞으면", cur.max_possible.toFixed(1), `기말 ${cur.final_ratio}% 반영`],
    ]));
    const ai = el("div", { class: "ai-box" });
    let opened = false;
    const btn = el("button", { class: "btn-ghost", type: "button" }, "취약점·보완 방법 보기");
    const close = () => { opened = false; ai.innerHTML = ""; btn.textContent = "취약점·보완 방법 보기"; };
    btn.addEventListener("click", async () => {
      if (opened) { close(); return; }                 // 열려 있으면 닫기
      opened = true;
      btn.textContent = "닫기";
      ai.innerHTML = "";
      ai.append(el("div", { class: "dim" }, "분석 문장을 만드는 중…"));
      try {
        const r = await api("POST", "/api/explain", { course_id: c.id, target_grade: tg });
        if (!opened) return;                           // 불러오는 중에 닫았으면 그대로 둠
        ai.innerHTML = "";
        ai.append(el("div", { class: "ai-tag" }, r.source === "ai" ? "AI가 계산 결과를 풀어 쓴 문장" : "기본 안내 문장 (규칙 기반)"),
          el("ul", {}, r.text.split("\n").filter((t) => t.trim()).map((t) => el("li", {}, t.replace(/^-\s*/, "")))),
          r.note ? el("div", { class: "dim" }, r.note) : null,
          el("div", { class: "dim" }, "숫자는 코드가 계산한 값이고, 문장만 설명용입니다."),
          el("button", { class: "btn-ghost", type: "button", onclick: close }, "닫기"));
      } catch (err) { ai.innerHTML = ""; ai.append(el("div", { class: "msg" }, err.message)); }
    });
    box.append(el("div", { class: "row" }, btn), ai);
  };
  draw();
  return box;
}

$("predictBtn").addEventListener("click", async () => {
  say("pMsg", "");
  $("predictResult").innerHTML = "";
  try {
    const r = await api("GET", "/api/predict");
    const out = $("predictResult");
    const sigma = r.uncertainty;

    out.append(el("div", { class: "callout" },
      el("b", {}, "이 결과는 확정된 성적이 아닙니다. "),
      `입력한 점수·평균·표준편차로 반 안에서의 위치를 추정하고, 기말까지 점수가 표준편차의 ${sigma}배 정도 바뀔 수 있다고 가정한 참고용 예측입니다. ${S.current.some((c) => c.exam_ratio !== undefined) ? "출석·과제를 넣은 과목은 반영 비율로 합친 점수로 계산하고(출석·과제 반 평균·표준편차는 예시값 가정), 기말고사 점수는 모르므로 지금까지 점수 기준으로 예측합니다." : "출석·과제 등 다른 평가 항목은 반영하지 않습니다."}`));

    const candIds = new Set(CANDS.filter((x) => x.source === "current").map((x) => x.id));
    const rows = S.current.map((c) => {
      const e = r.estimates[c.id];
      const range = e.best === e.worst ? e.expected : `${e.worst} ~ ${e.best}`;
      return tr([c.name, c.credit, e.z.toFixed(2), "상위 " + e.top_percent.toFixed(0) + "%", e.max_grade, e.min_grade, range,
        el("span", { class: "acts" },
          el("button", { class: "btn-link", onclick: () => goWithdraw(c.id) }, "철회 분석"),
          candIds.has(c.id) ? el("button", { class: "btn-link", onclick: () => goRetake("current", c.id) }, "재수강 분석") : null)]);
    });
    out.append(el("div", { class: "sub-title" }, "과목별 받을 수 있는 학점 (최대 · 최소)"));
    out.append(el("p", { class: "hint" }, "학칙은 A0 이상 30% 이하, B0 이상 70% 이하만 정하고, A+/A0 비율은 교수님이 정합니다. 그래서 현재 위치에서 받을 수 있는 최대와 최소를 보여 줍니다."));
    out.append(table(["과목명", "학점", term("z"), term("top"), term("maxg"), term("ming"), term("range"), ""], rows));

    const planCourses = S.current.filter((c) => r.final_needed[c.id]);
    if (planCourses.length) {
      if (!planCourses.some((c) => c.id === planPick)) planPick = planCourses[0].id;   // 처음엔 첫 과목
      const host = el("div", {});
      const show = () => {
        const c = planCourses.find((x) => x.id === planPick);
        host.innerHTML = "";
        host.append(renderFinalPlan(c, r.final_needed[c.id], () => {
          const pick = el("select", { class: "course-sel", "aria-label": "과목 선택", onchange: (e) => { planPick = e.target.value; show(); } },
            planCourses.map((x) => el("option", { value: x.id }, x.name)));
          pick.value = planPick;
          return pick;
        }));
      };
      show();
      out.append(host);
    }
    const cd = await api("GET", "/api/chart-data");
    if (cd.radar.axes.length) {
      out.append(el("div", { class: "sub-title" }, "과목별 현재 환산 점수 vs 반 평균"));
      out.append(el("p", { class: "hint" }, "항목별 반영 비율로 합친 지금까지의 환산 점수입니다. 반 평균은 중간고사 평균과 가정값(출석·과제 등)을 비율대로 합친 값입니다."));
      out.append(radarChart(cd.radar));
    }
    out.append(el("div", { class: "row dl-row" },
      el("span", { class: "dim" }, "그래프 데이터 내려받기 (발표·엑셀용):"),
      el("a", { class: "btn-link", href: "/api/chart-data?download=1", download: "gradepath_chart_data.json" }, "JSON"),
      el("a", { class: "btn-link", href: "/api/chart-data?format=csv", download: "gradepath_chart_data.csv" }, "CSV")));

    const sc = r.scenarios;
    out.append(el("div", { class: "sub-title" }, "이번 학기 이후 평균 학점 시나리오"));
    out.append(el("p", { class: "hint" }, "'이번 학기 평균 학점'는 이번 학기 과목만, '전체 누적 평균 학점'는 지난 학기까지 포함한 값입니다. 현재 누적 평균 학점(이번 학기 반영 전): ", f2(r.base_gpa)));
    const rs = r.rule_scenarios;
    out.append(table(["", term("semgpa"), term("cumgpa")], [
      tr(["현재 점수 기준 최대 (모든 과목 최대 학점)", f2(rs.max.semester_gpa), f2(rs.max.cumulative_gpa)]),
      tr(["현재 점수 기준 최소 (모든 과목 최소 학점)", f2(rs.min.semester_gpa), f2(rs.min.cumulative_gpa)]),      tr(["점수가 내려가면 (참고, 비관)", f2(sc.pessimistic.semester_gpa), f2(sc.pessimistic.cumulative_gpa)]),
      tr(["예상 (누적 비율표 기준)", f2(sc.expected.semester_gpa), f2(sc.expected.cumulative_gpa)]),
      tr(["점수가 올라가면 (참고, 낙관)", f2(sc.optimistic.semester_gpa), f2(sc.optimistic.cumulative_gpa)]),
    ]));

    out.append(el("div", { class: "sub-title" }, `목표 누적 평균 학점 ${r.target_gpa.toFixed(2)} 달성 가능성 (모의 계산)`));
    const need = r.required_avg_point;
    const needText = r.already_secured ? "이미 달성 가능권" : (!r.reachable ? "4.5 초과 (불가능)" : need.toFixed(2));
    out.append(cards([
      [term("need"), needText, "이번 학기 학점 가중 평균"],
      [term("prob"), r.probability_label, `모의 ${r.trials}번 중 ${r.hits}번 목표 도달`],
      [term("gparange"), `${f2(r.gpa_p10)} ~ ${f2(r.gpa_p90)}`, "중앙값 " + f2(r.gpa_p50)],
    ]));
    out.append(el("div", { class: "callout" },
      "목표 달성 가능성은 점수 변동을 무작위로 가정한 모의 계산이며, 실제로 검증된 확률이 아닙니다. 가정의 자세한 내용은 '계산 기준 보기'에서 학교 규정과 구분해 확인할 수 있습니다."));
  } catch (err) { say("pMsg", err.message); }
});

/* 목표 GPA 시뮬레이션: 과목을 고르면 등급별 평균 학점 표를 보여 줌 */
function renderSimSelect() {
  const sel = $("simCourse");
  const prev = sel.value;
  fillSelect(sel, S.current.length ? S.current.map((c) => [c.id, `${c.name} (${c.credit}학점)`]) : [["", "이번 학기 과목이 없습니다"]], prev);
  $("simResult").innerHTML = "";
}

async function runSimulate() {
  say("simMsg", "");
  $("simResult").innerHTML = "";
  try {
    const r = await api("POST", "/api/simulate", { course_id: $("simCourse").value });
    const out = $("simResult");
    const need = r.needed_grade;
    out.append(cards([
      [`${r.course.name} 예상 학점 기준`, f2(r.base.cumulative_gpa), `예상 ${r.expected_grade} · 이번 학기 ${f2(r.base.semester_gpa)}`],
      ["목표 누적 평균 학점", r.target_gpa.toFixed(2), "설정 탭에서 변경"],
      ["목표를 이루는 최소 학점", need || "불가능", need ? "이 등급 이상이면 목표 달성" : "어떤 등급을 받아도 목표 미달"],
    ]));
    out.append(el("p", { class: "hint" }, "다른 과목은 현재 점수 기준 예상 학점으로 고정한 값입니다. 확정 성적이 아닙니다."));
    out.append(table(["받는 학점", "이번 학기 평균 학점", "누적 평균 학점", "예상 대비 변화", "목표"],
      r.rows.map((x) => el("tr", { class: x.is_expected ? "picked" : "" },
        el("td", {}, x.grade + (x.is_expected ? " (예상)" : "")),
        el("td", { class: "num" }, f2(x.semester_gpa)),
        el("td", { class: "num" }, f2(x.cumulative_gpa)),
        el("td", { class: "num" }, el("span", { class: "pos" }, x.delta === null ? "-" : signed(x.delta))),
        el("td", { class: "num" }, x.meets_target ? "달성" : "미달")))));
  } catch (err) { say("simMsg", err.message); }
}
$("simBtn").addEventListener("click", runSimulate);
$("simCourse").addEventListener("change", () => { if ($("simCourse").value) runSimulate(); });

/* ---------- 3. 수강 철회 ---------- */

function renderWithdrawSelect() {
  const sel = $("wCourse");
  const prev = sel.value;
  fillSelect(sel, S.current.length ? S.current.map((c) => [c.id, `${c.name} (${c.credit}학점)`]) : [["", "이번 학기 과목이 없습니다"]], prev);
  $("withdrawResult").innerHTML = "";
}

function burdenParts(b) {
  const per = b.per_semester === null ? "-" : b.per_semester.toFixed(1) + "학점";
  return [b.label, `남은 학기당 ${per}` + (b.extra_semesters ? ` · 추가 ${b.extra_semesters}학기 필요` : "")];
}

function goWithdraw(id) {
  showTab("withdraw");
  $("wCourse").value = id;
  runWithdraw();
}

async function runWithdraw() {
  say("wMsg", "");
  $("withdrawResult").innerHTML = "";
  try {
    const r = await api("POST", "/api/withdraw", { course_id: $("wCourse").value });
    const out = $("withdrawResult");
    const e = r.estimate;
    const row = (label, a, b, fmt = f2) => tr([label, fmt(a), fmt(b), el("span", { class: "pos" }, diff(a, b))]);
    const x = r.expected, w = r.worst;
    out.append(el("div", { class: "wd-title" }, `${r.course.name} · 유지할까, 철회할까`));
    out.append(el("div", { class: "wd-sub" }, `현재 점수 기준 예상 ${e.expected} (예상 학점 범위 ${e.worst === e.best ? e.expected : e.worst + " ~ " + e.best})`));
    const dE = x.withdraw.gpa - x.stay.gpa, dW = w.withdraw.gpa - w.stay.gpa;
    const dCr = x.withdraw.earned - x.stay.earned;
    const big = Math.max(Math.abs(dE), Math.abs(dW));
    const r2 = (v) => Math.round(v * 100) / 100;
    const gpaPhrase = big < 0.05 ? ["거의 그대로", "이고,"]
      : (dE > 0 && dW > 0) ? ["올라가고", ","]
      : (dE < 0 && dW < 0) ? ["내려가고", ","]
      : [`기대 ${signed(r2(dE))} · 비관 ${signed(r2(dW))}로 갈리고`, ","];
    const crPhrase = dCr < 0 ? [el("u", {}, `${-dCr}학점`), " 줄어듭니다."] : dCr > 0 ? [el("u", {}, `${dCr}학점`), " 늘어납니다."] : ["변하지 않습니다."];
    out.append(el("div", { class: "wd-head" }, "철회하면 누적 평균은 ", big < 0.05 ? el("u", {}, gpaPhrase[0]) : gpaPhrase[0], gpaPhrase[1], el("br"), "취득 학점이 ", crPhrase));
    const R = Math.max(0.1, Math.ceil(big / 0.05) * 0.05);
    const pos = (v) => Math.max(4, Math.min(96, 50 + (v / R) * 50));
    const pE = pos(dE), pW = pos(dW), close = Math.abs(pE - pW) < 14;
    const lab = (name, d, p, side) => el("div", { class: "wd-lab", style: `left:${p}%;transform:translateX(${close ? (side === "l" ? "-100%" : "0") : "-50%"});text-align:${close ? (side === "l" ? "right" : "left") : "center"}` },
      name, el("b", {}, d === 0 ? "0.00" : signed(r2(d))));
    const eLeft = pE <= pW;
    out.append(el("div", { class: "wd-q" }, "철회하면 누적 평균 학점이 얼마나 달라지나"));
    out.append(el("div", { class: "wd-hint" }, "가운데 선(0)이 유지했을 때입니다. 오른쪽이 오름, 왼쪽이 내림입니다."));
    out.append(el("div", { class: "wd-axis" },
      el("div", { class: "wd-line" }), el("div", { class: "wd-zero" }),
      el("div", { class: "wd-range", style: `left:${Math.min(pE, pW)}%;width:${Math.abs(pE - pW)}%` }),
      el("i", { class: "wd-dot fill", style: `left:${pE}%` }), el("i", { class: "wd-dot", style: `left:${pW}%` }),
      lab("기대", dE, pE, eLeft ? "l" : "r"), lab("비관", dW, pW, eLeft ? "r" : "l"),
      el("div", { class: "wd-ticks" }, el("span", { style: "left:0" }, signed(-R)), el("span", { class: "z", style: "left:50%" }, "0 (유지)"), el("span", { style: "right:0" }, signed(R)))));
    const st = (label, a, b, extra) => el("div", { class: "wd-stat" }, el("div", { class: "wd-sl" }, label),
      el("div", { class: "wd-sv" }, `${a} → ${b}`, extra ? el("small", {}, ` (${extra})`) : null));
    out.append(el("div", { class: "wd-stats" },
      st("누적 평균 학점 (기대)", f2(x.stay.gpa), f2(x.withdraw.gpa)),
      st("이번 학기 후 취득 학점", x.stay.earned, x.withdraw.earned, (dCr > 0 ? "+" : "") + dCr),
      st("졸업까지 남은 학점", x.stay.burden.remaining, x.withdraw.burden.remaining, "+" + (x.withdraw.burden.remaining - x.stay.burden.remaining))));
    const det = el("details", { class: "howto" }, el("summary", {}, "자세한 표 보기 (학기 평균 학점 등)"));
    det.append(table(["", "유지", "철회", "차이"], [
      row(el("span", {}, term("semgpa"), " (기대)"), x.stay.semester_gpa, x.withdraw.semester_gpa),
      row(el("span", {}, term("semgpa"), " (비관)"), w.stay.semester_gpa, w.withdraw.semester_gpa),
      row(el("span", {}, term("cumgpa"), " (기대)"), x.stay.gpa, x.withdraw.gpa),
      row(el("span", {}, term("cumgpa"), " (비관)"), w.stay.gpa, w.withdraw.gpa),
      tr(["이번 학기 후 취득 학점", x.stay.earned, x.withdraw.earned, el("span", { class: "pos" }, dCr + "")]),
      tr(["졸업까지 남은 학점", x.stay.burden.remaining, x.withdraw.burden.remaining,
        el("span", { class: "pos" }, "+" + (x.withdraw.burden.remaining - x.stay.burden.remaining))]),
    ]));
    out.append(det);
    out.append(el("div", { class: "sub-title" }, "남은 학기 수강 부담"));
    out.append(cards([
      ["유지", ...burdenParts(x.stay.burden)],
      ["철회", ...burdenParts(x.withdraw.burden)],
    ], true));
    const bs = x.stay.burden;
    if (bs.seasonal_plan > 0) {
      out.append(el("p", { class: "hint" }, `설정에 입력한 계절학기 계획 ${bs.seasonal_plan}학점을 반영한 값입니다. (계절학기를 쓰지 않으면 학기당 ${f2(bs.per_semester_without_seasonal)}학점)`));
    }
    out.append(el("div", { class: "callout" }, "참고 정리",
      el("ul", {}, r.notes.map((n) => el("li", {}, n)))));
  } catch (err) { say("wMsg", err.message); }
}
$("wBtn").addEventListener("click", runWithdraw);

/* ---------- 4. 재수강 ---------- */

function renderRetakeList() {
  const box = $("retakeList");
  box.innerHTML = "";
  $("retakeHint").textContent =
    `기존 성적이 ${S.settings.retake_max_prior} 이하인 과목만 재수강할 수 있습니다. '분석'을 누르면 재수강으로 받을 성적별 평균 학점 변화를 보여 줍니다. ('내 성적'과 '성적 예측' 결과에서도 바로 연결됩니다.)`;
  if (CANDS.length === 0) {
    box.append(el("div", { class: "empty" }, `재수강 가능한 과목이 없습니다 (${S.settings.retake_max_prior} 이하 성적만 가능)`));
    return;
  }
  box.append(table(["과목명", "출처", "학점", "성적", ""],
    CANDS.map((c) => {
      const on = lastRetake && lastRetake.source === c.source && lastRetake.id === c.id;
      return el("tr", { class: on ? "picked" : "" },
        el("td", {}, c.name + (c.required ? " · 필수" : "")),
        el("td", { class: "num" }, c.where),
        el("td", { class: "num" }, c.credit),
        el("td", { class: "num" }, c.grade + (c.source === "current" ? " (예상)" : "")),
        el("td", { class: "num acts" }, el("button", { class: "btn-link", onclick: () => runRetake(c.source, c.id) }, "분석")));
    })));
}

/* 재수강 결과: 받는 성적별 막대 (가운데 선이 지금 누적 평균 학점) */
function retakeView(r) {
  const EPS = 0.0049;
  const rows = [];                                    // 상한 때문에 같은 반영 성적이 되는 줄은 "A+ · A0"로 합침
  for (const x of r.rows) {
    const same = rows.find((y) => y.applied === x.applied);
    if (same) { same.labels.push(x.received); same.capped = same.capped || x.capped; }
    else rows.push({ applied: x.applied, labels: [x.received], delta: x.delta, gpa: x.gpa, earned_delta: x.earned_delta, capped: !!x.capped });
  }
  const kind = (d) => (d > EPS ? "up" : d < -EPS ? "down" : "same");
  const maxAbs = Math.max(0.01, ...rows.map((g) => Math.abs(g.delta)));
  const row = (g) => {
    const k = kind(g.delta);
    const w = k === "same" ? 0 : Math.max(2, (Math.abs(g.delta) / maxAbs) * 62);
    const bar = el("i", { class: "rt-bar " + k, style: `width:${w}%` });
    const num = el("b", {}, k === "same" ? "0.00" : signed(g.delta));
    const note = g.earned_delta < 0 ? el("span", { class: "rt-note" }, `취득 학점 ${g.earned_delta}`) : null;
    let left, right;
    if (k === "down") { left = el("div", { class: "rt-half left" }, note, num, bar); right = el("div", { class: "rt-half right" }); }
    else if (k === "up") { left = el("div", { class: "rt-half left" }); right = el("div", { class: "rt-half right" }, bar, num, note); }
    else { left = el("div", { class: "rt-half left" }, el("span", { class: "rt-note" }, "변화 없음 (지금 성적)")); right = el("div", { class: "rt-half right" }, num); }
    const out = [el("div", { class: "rt-row " + k },
      el("div", { class: "rt-grade" }, g.labels.join(" · ")),
      el("div", { class: "rt-bars" }, left, right),
      el("div", { class: "rt-after" }, f2(g.gpa)))];
    if (g.labels.length > 1 && g.capped) out.push(el("div", { class: "rt-cap" }, `재수강은 최고 ${S.settings.retake_cap}까지만 반영되어, ${g.labels[0]}를 받아도 ${g.applied}와 같습니다.`));
    return out;
  };
  const wrap = el("div", { class: "rt" },
    el("div", { class: "rt-sub" }, `지금 누적 평균 학점은 `, el("b", {}, f2(r.base_gpa)), `입니다. 재수강에서 받는 성적에 따라 이렇게 달라집니다.`),
    el("div", { class: "rt-legend" }, el("span", {}, el("i", { class: "rt-bar up" }), "올라감"), el("span", {}, el("i", { class: "rt-bar down" }), "내려감")),
    el("div", { class: "rt-head" }, el("span", {}, "받는 성적"), el("span", { class: "c" }, `누적 평균 학점 변화 (가운데가 지금 ${f2(r.base_gpa)})`), el("span", { class: "r" }, "재수강 후 누적")));
  const body = el("div", { class: "rt-body" });
  rows.forEach((g) => row(g).forEach((n) => body.append(n)));
  wrap.append(body);
  return wrap;
}

function goRetake(source, id) {
  showTab("retake");
  runRetake(source, id);
}

async function runRetake(source, id) {
  say("rMsg", "");
  $("retakeResult").innerHTML = "";
  lastRetake = { source, id };
  renderRetakeList();
  try {
    const r = await api("POST", "/api/retake", {
      source, course_id: id, other_credits: $("rOtherCredits").value, other_avg_point: $("rOtherAvg").value,
    });
    const out = $("retakeResult");
    out.append(el("div", { class: "sub-title" },
      `${r.course.name} (${r.course.credit}학점, 기존 ${r.course.grade}${source === "current" ? " · 이번 학기 예상" : ""})`));
    out.append(cards([
      ["현재 성적 유지 시 누적 평균 학점", f2(r.base_gpa), `${r.course.name} ${r.course.grade}`],
      ["재수강 시 누적 평균 학점 최대 상승", signed(r.max_gain), "성적 상한 적용"],
      ["평균 학점이 오르는 최저 성적", r.break_even || "없음", "이 성적 이상 받아야 이득"],
    ]));
    out.append(el("div", { class: "sub-title" }, "재수강 성적별 결과"));
    const semHead = r.other_credits > 0 ? "재수강 학기 평균 학점" : "재수강 학기 평균 학점 (이 과목만)";
    out.append(retakeView(r));
    out.append(el("details", { class: "howto" }, el("summary", {}, "자세한 표 보기"),
      table(["받는 성적", "반영 성적", semHead, "재수강 후 누적 평균 학점", "누적 변화", "취득 학점 변화"],
        r.rows.map((x) => tr([
          x.received, x.applied + (x.capped ? " (상한)" : ""), f2(x.semester_gpa), f2(x.gpa),
          el("span", { class: "pos" }, signed(x.delta)), x.earned_delta > 0 ? "+" + x.earned_delta : x.earned_delta,
        ])))));
    const notes = [];
    if (r.course.required && r.course.grade === "F") notes.push("필수 과목을 F로 낙제했으므로 반드시 재수강해서 학점을 취득해야 합니다.");
    notes.push("재수강 학기 평균 학점은 재수강한 학기만의 평점평균이고, 누적 평균 학점은 재수강 성적이 예전 성적을 대체한 뒤 전체를 합쳐 계산한 값입니다.");
    notes.push(`재수강하면 다음 학기 ${r.burden_credit}학점(학기 최대의 ${(r.burden_ratio * 100).toFixed(0)}%)을 이 과목에 쓰게 됩니다.`);
    notes.push(`재수강 성적이 예전 성적을 대체한다고 가정한 계산입니다. 최고 성적은 ${S.settings.retake_cap}까지 반영됩니다.`);
    if (source === "current") notes.push("이번 학기 과목은 현재 점수 기준 예상 성적이 확정된다고 가정했습니다. 실제 성적이 나온 뒤 다시 확인하세요.");
    out.append(el("div", { class: "callout" }, "참고 정리", el("ul", {}, notes.map((n) => el("li", {}, n)))));
  } catch (err) { say("rMsg", err.message); }
}
for (const id of ["rOtherCredits", "rOtherAvg"]) {
  $(id).addEventListener("change", () => { if (lastRetake) runRetake(lastRetake.source, lastRetake.id); });
}

/* ---------- 5. 설정 ---------- */

function renderSettings() {
  const s = S.settings;
  $("sTotal").value = s.total_credits_required;
  $("sMajor").value = s.major_credits_required;
  $("sMax").value = s.max_credits_per_semester;
  $("sMaxYear").value = s.max_credits_per_year;
  $("sSem").value = s.remaining_semesters;
  $("sSeasonal").value = s.seasonal_plan_credits;
  $("sTarget").value = s.target_gpa;
  const g = S.grades.map((x) => [x, x]);
  fillSelect($("sCap"), g, s.retake_cap);
  fillSelect($("sPrior"), g, s.retake_max_prior);
  renderRules($("rulesSettings"));
}

$("settingsForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  say("sMsg", "");
  try {
    await api("PUT", "/api/settings", {
      total_credits_required: $("sTotal").value, major_credits_required: $("sMajor").value, max_credits_per_semester: $("sMax").value, max_credits_per_year: $("sMaxYear").value,
      remaining_semesters: $("sSem").value, seasonal_plan_credits: $("sSeasonal").value, target_gpa: $("sTarget").value,
      retake_cap: $("sCap").value, retake_max_prior: $("sPrior").value,
    });
    say("sMsg", "저장했습니다.");
    await loadAll();
    renderSetupNotice();
  } catch (err) { say("sMsg", err.message); }
});

loadAll().then(() => { if (!S.onboarded) openIntro(); });


/* ---------- 학업 가이드 ---------- */

let guideBusy = null;      // 바쁜 학기 번호 목록 (null이면 서버 기본값: 4학년 학기)
let guidePlan = null;      // 보고 있는 배분안 (even / balanced / minimal)

async function renderGuide() {
  const g = await api("GET", "/api/guide" + (guideBusy === null ? "" : "?busy=" + guideBusy.join(",")));
  const p = $("guideProgress");
  p.innerHTML = "";
  p.append(progressBar("전체 학점", g.progress.total.done, g.progress.total.now, g.progress.total.required),
    progressBar("전공 학점", g.progress.major.done, g.progress.major.now, g.progress.major.required),
    el("div", { class: "hint legend-note" }, "진한 부분은 취득한 학점, 연한 부분은 이번 학기 과목을 모두 취득할 경우 더해지는 학점입니다."));

  const bz = $("guideBusy"), pl = $("guidePlans"), t = $("guideTable"), ai = $("guideAi");
  bz.innerHTML = ""; pl.innerHTML = ""; t.innerHTML = ""; ai.innerHTML = "";
  if (g.plans.length === 0) {
    t.append(el("div", { class: "empty" }, "남은 학기가 없습니다. 설정에서 남은 정규 학기 수를 확인해 주세요."));
  } else {
    const boxes = g.future.map((f) => {
      const cb = el("input", { type: "checkbox" });
      cb.checked = g.busy.includes(f.idx);
      cb.addEventListener("change", () => {
        guideBusy = [...bz.querySelectorAll("input")].map((x, i) => (x.checked ? g.future[i].idx : null)).filter((x) => x !== null);
        guidePlan = null;
        renderGuide();
      });
      return el("label", { class: "check" }, cb, `${f.year}학년 ${f.term}학기`);
    });
    bz.append(el("div", { class: "opt-title" }, "바쁜 학기 (취업 준비 등으로 적게 듣고 싶은 학기)"), el("div", { class: "row busy-row" }, boxes));

    const multi = g.busy.length > 0 && g.busy.length < g.future.length;
    const plans = multi ? g.plans : [g.plans[0]];
    if (!plans.some((x) => x.key === guidePlan)) guidePlan = multi ? g.default_plan : "even";
    const cur = plans.find((x) => x.key === guidePlan);
    if (multi) {
      pl.append(el("div", { class: "seg plan-seg", role: "group" }, plans.map((x) =>
        el("button", { type: "button", class: x.key === guidePlan ? "on" : "", onclick: () => { guidePlan = x.key; renderGuide(); } },
          x.name + (x.key === g.default_plan ? " (추천)" : "")))));
      pl.append(el("div", { class: "hint plan-help" },
        { even: "모든 학기를 고르게 나눕니다.", balanced: "바쁜 학기는 줄이고, 나머지 학기가 나눠서 더 듣습니다.", minimal: "바쁜 학기를 졸업에 꼭 필요한 최소 학점으로 줄입니다. 나머지 학기가 가장 빡빡해집니다." }[guidePlan]));
    }
    t.append(table(["학기", "권장 학점", "전공", "교양·기타", "비고"], cur.rows.map((r) =>
      tr([`${r.year}학년 ${r.term}학기` + (r.kind === "now" ? " (이번 학기)" : ""), r.credits, r.major, r.lib,
        r.kind === "now" ? "입력한 과목 기준" : (r.busy ? "바쁜 학기" : (r.cap && r.credits >= r.cap ? "학기 한도" : ""))]))));
    t.append(el("div", { class: "callout" }, cur.summary));

    const box = el("div", { class: "ai-box" });
    let opened = false;
    const btn = el("button", { class: "btn-ghost", type: "button" }, "배분안 설명 보기");
    const close = () => { opened = false; box.innerHTML = ""; btn.textContent = "배분안 설명 보기"; };
    btn.addEventListener("click", async () => {
      if (opened) { close(); return; }
      opened = true; btn.textContent = "닫기"; box.innerHTML = "";
      box.append(el("div", { class: "dim" }, "설명을 만드는 중…"));
      try {
        const r = await api("POST", "/api/explain-guide", { busy: g.busy });
        if (!opened) return;
        box.innerHTML = "";
        box.append(el("div", { class: "ai-tag" }, r.source === "ai" ? "AI가 계산 결과를 풀어 쓴 문장" : "기본 안내 문장 (규칙 기반)"),
          el("ul", {}, r.text.split("\n").filter((x) => x.trim()).map((x) => el("li", {}, x.replace(/^-\s*/, "")))),
          r.note ? el("div", { class: "dim" }, r.note) : null,
          el("div", { class: "dim" }, "숫자는 코드가 계산한 값이고, 문장만 설명용입니다."),
          el("button", { class: "btn-ghost", type: "button", onclick: close }, "닫기"));
      } catch (err) { box.innerHTML = ""; box.append(el("div", { class: "msg" }, err.message)); }
    });
    ai.append(el("div", { class: "row" }, btn), box);
  }
  const n = $("guideNote");
  n.innerHTML = "";
  n.append(el("div", { class: "callout" },
    `졸업 부담: ${g.burden_label}` + (g.extra_semesters > 0 ? ` · 지금 계획으로는 정규 학기가 ${g.extra_semesters}학기 더 필요합니다.` : ""),
    g.seasonal_plan > 0 ? el("div", { class: "dim" }, `계절학기 계획 ${g.seasonal_plan}학점을 반영해 정규 학기 권장 학점을 줄였습니다.`) : null));
}
$("goWithdraw").addEventListener("click", () => showTab("withdraw"));
$("goRetake").addEventListener("click", () => showTab("retake"));
